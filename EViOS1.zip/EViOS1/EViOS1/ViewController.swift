//
//  ViewController.swift
//  EViOS1
//
//  Created by Jérôme Danthinne on 30/06/2023.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var avatarImage: UIImageView!
    @IBOutlet var loginField: UITextField!
    @IBOutlet var passwordField: UITextField!
    @IBOutlet var passwordSwitcher: UIButton!
    @IBOutlet var isSubscribed: UISwitch!
    @IBOutlet var loader: UIActivityIndicatorView!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Arrondi de l'avatar
        avatarImage.layer.cornerRadius = avatarImage.frame.height / 2

        // Aspect de l'image dans le bouton
        passwordSwitcher.imageView?.contentMode = .scaleAspectFit

        // Gestion du clavier
        let tapGesture = UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing))
        view.addGestureRecognizer(tapGesture)

        // Etat initial
        loader.isHidden = true
    }

    @IBAction func passwordSwitcherTap() {
        passwordField.isSecureTextEntry.toggle()

        let imageName = passwordField.isSecureTextEntry ? "eye_off_icon" : "eye_on_icon"
        passwordSwitcher.setImage(UIImage(named: imageName), for: .normal)
    }

    @IBAction func loginTap() {
        guard let login = loginField.text,
              let password = passwordField.text
        else {
            return
        }

        // Validation des champs
        guard !login.isEmpty else {
            displayErrorAlert(message: "Le login ne peut être vide.")
            return
        }

        guard !password.isEmpty else {
            displayErrorAlert(message: "Le mot de passe ne peut être vide.")
            return
        }

        guard login.contains("@") else {
            displayErrorAlert(message: "Le login n'est pas une adresse valide.")
            return
        }

        guard password.count >= 4 else {
            displayErrorAlert(message: "La longueur du mot de passe doit être supérieur à 4.")
            return
        }

        // On affiche le loader
        loader.isHidden = false
        loader.startAnimating()

        // On lance le travail en arrière-plan
        registerForNewsletter {
            // Le travail est fini, on change l'interface sur le thread UI
            DispatchQueue.main.async {
                self.loader.isHidden = true
                self.displaySuccessAlert(login: login,
                                         isSubscribed: self.isSubscribed.isOn)
            }
        }
    }

    func displaySuccessAlert(login: String, isSubscribed: Bool) {
        let alert = UIAlertController(
            title: "Bienvenue \(login)",
            message: isSubscribed ? "Vous vous êtes inscrit à la newsletter." : "Vous ne vous êtes pas inscrit à la newsletter.",
            preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Merci !", style: .default))
        present(alert, animated: true)
    }

    func displayErrorAlert(message: String) {
        let alert = UIAlertController(
            title: "ERROR",
            message: message,
            preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    func registerForNewsletter(completion: @escaping () -> Void) {
        DispatchQueue.global(qos: .userInitiated).async {
            sleep(3)
            completion()
        }
    }
}

